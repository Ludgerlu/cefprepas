<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Event;

class EtudiantController extends Controller
{
    public function index(){
        $events = Event::where('type','Student Life / Vie d\'Etudiant')->latest()->get();
        return view('user.etudiants.index', compact('events'));
    }

    public function show(Event $event){
        return view('user.etudiants.show',compact('event'));
    }
}
